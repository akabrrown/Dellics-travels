(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1owyi95._.css","static/chunks/apps_web_src_0sk1gyn._.js","static/chunks/node_modules_next_0xwspze._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0q79z23._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_1vqrmkg._.js","static/chunks/_0qzu2ku._.js","static/chunks/apps_web_src_0y-4ufn._.js","static/chunks/_164yfzd._.js"],
    source: "entry"
});
